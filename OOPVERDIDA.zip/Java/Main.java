 // Import statements
import java.util.Scanner;

// Motor interface with description and buy methods
interface Motor {
    void description();
    void buy(String name, String lastName, int quantity);

    
}

// Abstract Motors class implementing Motor interface
abstract class Motors implements Motor { //abstraction
    // Private attributes for motor details
    private String motorName;
    private String model;
    private String color;
    int price;

    // Constructor for Motors class
    Motors(String motorName, String model) {
        this.motorName = motorName;
        this.model = model;
        setPriceBasedOnMotor();
    }

    // Abstract method to set price based on motor
    abstract void setPriceBasedOnMotor();

    // Method to display motor details
    @Override
    public void description() {
        System.out.println("Motor brand: " + motorName);
        System.out.println("Motor model: " + model);
        System.out.println("Color: " + color);
        System.out.println("Price: Php " + price);
    }

    // Method to process a purchase
    @Override
    public void buy(String name, String lastName, int quantity) {
        int totalPrice = quantity * price;
        System.out.println("\nPurchase Details:");
        System.out.println("Name of the owner: " + name + " " + lastName);
        System.out.println("Motor brand and model: " + motorName + " " + model);
        System.out.println("Color: " + color);
        System.out.println("Quantity of sold bikes: " + quantity);
        System.out.println("Total Price: Php " + totalPrice);
    }

    // Getter methods for motor details
    String getMotorName() {
        return motorName;
    }

    String getModel() {
        return model;
    }

    String getColor() {
        return color;
    }

    int getPrice() {
        return price;
    }

    // Setter method for color
    void setColor(String color) {
        this.color = color;
    }
}

// MotorA class extending Motors
class MotorA extends Motors {
    // Constructor for MotorA
    MotorA(String color) {
        super("Triumph", "Rocket 3 GT");
        setColor(color);
    }

    @Override
    void setPriceBasedOnMotor() {
        // You need to set the price for MotorA here
        // For example, let's set a fixed price of 2000000
        this.price = 2000000;
    }
}


// MotorB class extending Motors
class MotorB extends Motors {
    // Constructor for MotorB
    MotorB(String color) {
        super("MV Agusta", "Brutale RR 1000");
        // Setting color using the provided parameter
        setColor(color);
    }

    @Override
    void setPriceBasedOnMotor() {
        // Setting the price for MotorB
        this.price = 2200000;
    }

    @Override
    public void description() {
        // Calling the description method of the superclass and adding additional details
        super.description();
        System.out.println("Additional details for Brutale RR 1000...");
    }
}

// MotorC class extending Motors
class MotorC extends Motors {
    // Constructor for MotorC
    MotorC(String color) {
        super("Harley-Davidson", "CVO Street Glide");
        // Setting color using the provided parameter
        setColor(color);
    }

    @Override
    void setPriceBasedOnMotor() {
        // Setting the price for MotorC
        this.price = 4200000;
    }

    @Override
    public void description() {
        // Calling the description method of the superclass
        super.description();
    }
}
// Main class for JGRC Moto System
public class main {
    public static void main(String[] args) {
        // Creating a Scanner object for user input
        Scanner s = new Scanner(System.in);

        // Displaying initial message
        System.out.println("\t\t\t\t\t\t\t\t\t\t\tJGRC MOTO SYSTEM\n\n");

        // Prompting user for name and last name
        System.out.print("Enter the name: ");
        String name = s.nextLine();
        System.out.print("Enter the last name: ");
        String lastName = s.nextLine();

        // Displaying available motors and getting user choice
        System.out.println("Motors\n"
                      +"1. TRIUMPH\n"
                      +"2. MV AGUSTA\n"
                      +"3. HARLEY-DAVIDSON\n");
        int choice = getUserChoice(s);

        // Prompting user for color
        System.out.print("Enter the color: ");
        String color = s.next();

        // Getting the selected motor based on user choice and color
        Motors chosenMotor = getMotorByChoice(choice, color);

        // If a valid motor is selected
        if (chosenMotor != null) {
            // Displaying motor details
            chosenMotor.description();

            // Prompting user for quantity to buy
            System.out.print("Enter the quantity to buy: ");
            int quantity = getUserInput(s);

            // Processing the purchase
            chosenMotor.buy(name, lastName, quantity);
        }
    }

    // Method to get user choice for motors
    private static int getUserChoice(Scanner s) {
        int choice = 0;
        try {
            choice = s.nextInt();
        } catch (Exception e) {
            // Handling invalid input
            System.out.println("Invalid input. Please enter a valid number.");
            System.exit(0);
        }
        return choice;
    }

    // Method to get user input for quantity
    private static int getUserInput(Scanner s) {
        int input = 0;
        try {   
            input = s.nextInt();
        } catch (Exception e) { // exception
            // Handling invalid input
            System.out.println("Invalid input. Please enter a valid number.");
            System.exit(0);
        }
        return input;
    }

    // Method to get the selected motor based on user choice and color
    private static Motors getMotorByChoice(int choice, String color) {
        Motors chosenMotor = null;

        // Switch case to determine the selected motor
        switch (choice) {
            case 1:
                chosenMotor = new MotorA(color);
                break;

            case 2:
                chosenMotor = new MotorB(color);
                break;

            case 3:
                chosenMotor = new MotorC(color);
                break;

            default:
                // Handling invalid choice
                System.out.println("Invalid choice. Exiting program.");
                System.exit(0);
        }

        return chosenMotor;
    }
}
